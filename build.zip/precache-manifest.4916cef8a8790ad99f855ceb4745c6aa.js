self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "345d2eb740207fe623b8cb1bd8965dec",
    "url": "/index.html"
  },
  {
    "revision": "1b2e8a8f27d654a7d628",
    "url": "/static/css/2.08577705.chunk.css"
  },
  {
    "revision": "97430b252fb3cbbe310d",
    "url": "/static/css/main.5a378ce3.chunk.css"
  },
  {
    "revision": "1b2e8a8f27d654a7d628",
    "url": "/static/js/2.6937e098.chunk.js"
  },
  {
    "revision": "f5d3a0c9dc3a59abe9a30d11e192b2da",
    "url": "/static/js/2.6937e098.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97430b252fb3cbbe310d",
    "url": "/static/js/main.c8cd9436.chunk.js"
  },
  {
    "revision": "55740798f77ba87d00f0",
    "url": "/static/js/runtime-main.38a392f9.js"
  },
  {
    "revision": "d3ef460a142513c95062776b64a7a1d0",
    "url": "/static/media/balance.d3ef460a.png"
  },
  {
    "revision": "55d60c1429ece6807e7284e39b3638ed",
    "url": "/static/media/bitcolabi.55d60c14.svg"
  },
  {
    "revision": "a9c3c7f3c5aa620dd81f371ff7b98280",
    "url": "/static/media/bitcolabi2.a9c3c7f3.svg"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "/static/media/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "013f0b90a4cae7b8bbf13e3fd9e7dc4a",
    "url": "/static/media/getFetch.013f0b90.cjs"
  },
  {
    "revision": "4437d336d821cd25b8809650aaf70a15",
    "url": "/static/media/hoo4.4437d336.png"
  },
  {
    "revision": "5ed9fbaab09895ac95f4677e8aad7536",
    "url": "/static/media/order.5ed9fbaa.png"
  },
  {
    "revision": "2dbc4c833999f938731840aae8e25b1a",
    "url": "/static/media/orderbook.2dbc4c83.png"
  }
]);